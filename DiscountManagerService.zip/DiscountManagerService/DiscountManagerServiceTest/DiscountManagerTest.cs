﻿using DiscountManagerService.DiscountManager;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace DiscountManager.Tests
{
    [TestClass()]
    public class DiscountManagerTests
    {

        #region Private Variables
        public Mock<IDAL> mockDal = new Mock<IDAL>();
        public DiscountManager discountManager = null;
        #endregion

        [TestInitialize]
        public void Initialize()
        {

            var itemList = new List<ItemDiscountMapping>() {

        new ItemDiscountMapping { DiscountId = 2, HasDiscount = true, ItemId = 1 },
        new ItemDiscountMapping { DiscountId = 1, HasDiscount = false, ItemId = 2 } };

            var List = new List<DiscountMaster>() {

        new DiscountMaster { DiscountId = 2, DiscountContity = 3, Percentage = 100 },
        new DiscountMaster { DiscountId = 1, DiscountContity = 4, Percentage = 100 } };


            mockDal.Setup(y => y.GetDiscountMasters()).Returns(List);
            mockDal.Setup(y => y.GetItemDiscountMappings()).Returns(itemList);

            discountManager = new DiscountManager(mockDal.Object);
        }
        [TestMethod()]
        public void GetDiscountPriceTest()
        {
            //arrange  
            var itemList = new List<CartItem>() {

        new CartItem { ItemId = 1, ItemName = "Banana", Countity = 4, Price = 100 },
        new CartItem { ItemId = 2, ItemName = "Apple", Countity = 4, Price = 200 } };

            var result = discountManager.GetDiscountPrice(itemList);
            // //Assert
            Assert.IsNotNull(result);
        }
    }
}