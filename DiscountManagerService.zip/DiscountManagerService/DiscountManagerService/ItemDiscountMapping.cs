﻿namespace DiscountManager
{
    public class ItemDiscountMapping
    {
        public int DiscountId { get; set; }
        public int ItemId { get; set; }
        public bool HasDiscount { get; set; }
    }
}