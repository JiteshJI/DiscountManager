﻿using System.Collections.Generic;

namespace DiscountManager
{
    public class DAL : IDAL
    {
        public List<ItemDiscountMapping> GetItemDiscountMappings()
        {
            return new List<ItemDiscountMapping>() {

        new ItemDiscountMapping { DiscountId = 2, HasDiscount = true, ItemId = 1 },
        new ItemDiscountMapping { DiscountId = 1, HasDiscount = true, ItemId = 2 } };
        }

        public List<DiscountMaster> GetDiscountMasters()
        {
            return new List<DiscountMaster>() {

        new DiscountMaster { DiscountId = 2, DiscountContity = 3, Percentage = 100 },
        new DiscountMaster { DiscountId = 1, DiscountContity = 4, Percentage = 200 } };
        }
    }
}