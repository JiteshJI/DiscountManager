﻿using DiscountManagerService.DiscountManager;
using Ninject;
using System.Collections.Generic;
using System.Reflection;

namespace DiscountManager
{
    class Program
    {
        static void Main(string[] args)
        {
            var itemList = new List<CartItem>() {

        new CartItem { ItemId = 1, ItemName = "Banana", Countity = 3, Price = 100 },
        new CartItem { ItemId = 2, ItemName = "Apple", Countity = 4, Price = 200 } };


            // create a Ninject kernel to resolve dependancies in our code automatically
            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());
            var dal = kernel.Get<IDAL>();
            var caller = new DiscountManager(dal);

            var finalAmountAfterDiscount = caller.GetDiscountPrice(itemList);
        }
    }
}