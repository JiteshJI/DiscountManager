﻿using System.Collections.Generic;

namespace DiscountManager
{
    public interface IDAL
    {
        List<ItemDiscountMapping> GetItemDiscountMappings();
        List<DiscountMaster> GetDiscountMasters();
    }
}