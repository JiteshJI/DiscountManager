﻿using DiscountManagerService.DiscountManager;
using System.Collections.Generic;

namespace DiscountManager
{
    public interface IDiscountManager
    {
        decimal GetDiscountPrice(List<CartItem> cartItems);
    }
}