﻿namespace DiscountManager
{
    public class DiscountMaster
    {
        public int DiscountId { get; set; }
        public int DiscountContity { get; set; }
        public decimal Percentage { get; set; }
    }
}