﻿using DiscountManagerService.DiscountManager;
using System.Collections.Generic;

namespace DiscountManager
{
    public class DiscountManager : IDiscountManager
    {

        #region Public Variable
        private readonly IDAL _dAL;
        #endregion

        #region Public Methods
        public DiscountManager(IDAL dal)
        {
            _dAL = dal;
        }
        public decimal GetDiscountPrice(List<CartItem> cartItems)
        {

            decimal price = 0;

            for (int i = 0; i < cartItems.Count; i++)
            {
                decimal percentage = 0;
                var getDiscountMaster = GetDiscountFromMaster(cartItems[i].ItemId);

                if (getDiscountMaster != null)
                    percentage = GetDiscountPercentage(getDiscountMaster.DiscountId, cartItems[i].Countity);
                price = price + (cartItems[i].Countity * cartItems[i].Price) - ((cartItems[i].Price * percentage / 100));
            }

            return price;
        }
        #endregion

        #region Private Methods
        private ItemDiscountMapping GetDiscountFromMaster(int item)
        {
            //GetData from database 
            var lstItem = _dAL.GetItemDiscountMappings();
            return lstItem.Find(e => e.ItemId == item && e.HasDiscount);
        }
        private decimal GetDiscountPercentage(int discountId, int cartItemCountity)
        {
            //GetData from database 
            var lstItem = _dAL.GetDiscountMasters();
            var GetDiscountPercentage = lstItem.Find(e => e.DiscountId == discountId && e.DiscountContity <= cartItemCountity);
            if (GetDiscountPercentage != null) return GetDiscountPercentage.Percentage; else return 0;
        }
        #endregion 
    }
}