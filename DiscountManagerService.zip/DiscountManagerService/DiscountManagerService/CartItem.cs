﻿namespace DiscountManagerService
{
    namespace DiscountManager
    {
        public class CartItem
        {
            public int ItemId { get; set; }
            public string ItemName { get; set; }
            public decimal Price { get; set; }
            public int Countity { get; set; }
        }
    }
}
