﻿using Ninject.Modules;

namespace DiscountManager
{
    public class Bootstrap : NinjectModule
    {
        public override void Load()
        {
            Bind<IDAL>().To<DAL>();
        }
    }
}